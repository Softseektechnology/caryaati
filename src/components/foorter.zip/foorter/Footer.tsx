import { FaFacebook, FaTwitter, FaInstagram, FaLinkedin, FaYoutube } from 'react-icons/fa';
import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="text-white py-4" style={{ backgroundColor: '#f5f5f5', borderTop: '1px solid #d9e2e8' }}>
      <div className="container">
        <div className="row">
          {/* Company Section */}
          <div className="col-6 col-sm-6 col-md-3 mb-3">
            <h5 style={{ color: '#000' }}>Company</h5>
            <ul className="list-unstyled">
              <li><a href="#" className="text-black text-decoration-none">About</a></li>
              <li><a href="#" className="text-black text-decoration-none">Careers</a></li>
              <li><a href="#" className="text-black text-decoration-none">Mobile</a></li>
              <li><a href="#" className="text-black text-decoration-none">Blog</a></li>
              <li><a href="#" className="text-black text-decoration-none">How we work</a></li>
            </ul>
          </div>

          {/* Contact Section */}
          <div className="col-6 col-sm-6 col-md-3 mb-3">
            <h5 style={{ color: '#000' }}>Contact</h5>
            <ul className="list-unstyled">
              <li><a href="#" className="text-black text-decoration-none">Help/FAQ</a></li>
              <li><a href="#" className="text-black text-decoration-none">Press</a></li>
              <li><a href="#" className="text-black text-decoration-none">Affiliates</a></li>
              <li><a href="#" className="text-black text-decoration-none">Hotel owners</a></li>
              <li><a href="#" className="text-black text-decoration-none">Partners</a></li>
            </ul>
          </div>

          {/* More Section */}
          <div className="col-6 col-sm-6 col-md-3 mb-3">
            <h5 style={{ color: '#000' }}>More</h5>
            <ul className="list-unstyled">
              <li><a href="#" className="text-black text-decoration-none">Airline fees</a></li>
              <li><a href="#" className="text-black text-decoration-none">Airlines</a></li>
              <li><a href="#" className="text-black text-decoration-none">Low fare tips</a></li>
              <li><a href="#" className="text-black text-decoration-none">Badges & Certificates</a></li>
              <li><a href="#" className="text-black text-decoration-none">Security</a></li>
            </ul>
          </div>

          {/* App Download Section */}
          <div className="col-12 col-sm-6 col-md-3 mb-3">
            <h5 style={{ color: '#000' }}>Get the Caryaati app</h5>
            <a
              className="kR-5"
              href="https://play.google.com/store/apps/details?id=com.kayak.android"
              target="_blank"
              rel="noopener"
              aria-label="Get it on Google Play"
              title="Get it on Google Play"
            >
              {/* Google Play SVG (unchanged) */}
              <svg className="KcdG" width="140" height="60" viewBox="0 0 180 60" fill="none" xmlns="http://www.w3.org/2000/svg">
                {/* SVG content remains the same */}
              </svg>
            </a>
            <br />
            <a
              className="kR-5"
              href="https://apps.apple.com/us/app/kayak-flights-hotels-cars/id305204535"
              target="_blank"
              rel="noopener"
              aria-label="Download on the App Store"
              title="Download on the App Store"
            >
              {/* App Store SVG (unchanged) */}
              <svg className="c158n" width="140" height="60" viewBox="0 0 108 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                {/* SVG content remains the same */}
              </svg>
            </a>
          </div>
          
          {/* Contact Section */}
          <div className="col-6 col-sm-6 col-md-3 mb-3">
            <h5 style={{ color: '#000' }}>Important Reading</h5>
            <ul className="list-unstyled">
            <Link href="/Privacy-policy" className='text-black text-decoration-none me-3'>Privacy Policy</Link> 
            <Link href="/Terms-conditions" className='text-black text-decoration-none me-3'>Terms & Conditions</Link>
            <Link href="/Become-a-partner" className='text-black text-decoration-none me-3'>Become a Parthner</Link>
            </ul>
          </div>

          {/* More Section */}
          <div className="col-6 col-sm-6 col-md-3 mb-3">
            <h5 style={{ color: '#000' }}>Useful Link</h5>
            <ul className="list-unstyled">
          <li><Link href="/Blogs" className='text-black text-decoration-none me-3'>Blog</Link></li>  
          <li>  <Link href="/Contact-us" className='text-black text-decoration-none me-3'>Contant Us  </Link></li> 
          <li>  <Link href="/FAQ" className='text-black text-decoration-none me-3'>FAQ</Link></li> 
            </ul>
          </div>
        </div>

        <hr className="bg-white" />

        <div className="row align-items-center">
          {/* Copyright and Links */}
          <div className="col-12 col-md-6 mb-3 mb-md-0">
            <div className="d-flex flex-column flex-sm-row align-items-start align-sm-center">
              <p className="mb-0 me-sm-3" style={{ color: '#000' }}>©2025 Caryaati</p>
              <div className="d-flex flex-wrap">
            
                <Link href="/dashboard" className='text-black text-decoration-none me-3'>Privacy</Link>
                <a href="#" className="text-black text-decoration-none">Ad Choices</a>
              </div>
            </div>
          </div>

          {/* Social Media Icons */}
          <div className="col-12 col-md-6 text-md-end text-center">
            <div className="d-flex justify-content-center justify-content-md-end space-x-4">
              <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="text-black hover:text-blue-500">
                <FaFacebook size={24} />
              </a>
              <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="text-black hover:text-blue-400">
                <FaTwitter size={24} style={{ marginLeft: '10px' }} />
              </a>
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="text-black hover:text-pink-500">
                <FaInstagram size={24} style={{ marginLeft: '10px' }} />
              </a>
              <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="text-black hover:text-blue-600">
                <FaLinkedin size={24} style={{ marginLeft: '10px' }} />
              </a>
              <a href="https://youtube.com" target="_blank" rel="noopener noreferrer" className="text-black hover:text-red-600">
                <FaYoutube size={24} style={{ marginLeft: '10px' }} />
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}