import React from 'react';
import Image from 'next/image';
import styles from './RentalDealCard.module.css';

export default function CarAndMapLayout() {
  return (
    <>
    

      {/* Main Content Container */}
      <div>
        <div className="row">
          {/* Car Cards Column (8 units) */}
          <div className="col-md-8" style={{marginLeft:'-10px'}}>
            {/* Example Car Card */}
            <div className={styles.carCard}>
              {/* Left section with images */}
              <div className={styles.left}>
                <Image
                  src="/images/32_sedan_white.png"
                  alt="Car"
                  width={140}
                  height={100}
                  className={styles.image}
                />
                <div>
                  <Image
                    src="/images/company-logos/drive4less.jpg"
                    alt="Company"
                    width={140}
                    height={100}
                    className={styles.image1}
                  />
                </div>
              </div>

              {/* Middle section with details */}
              <div className={styles.middle}>
                <div className={styles.titleRow}>
                  <h3>Mitsubishi Mirage G4</h3>
                  <span className={styles.infoIcon}>ⓘ</span>
                </div>
                <p className={styles.subtext}>or similar Compact</p>
                <div className={styles.icons}>
                  <span>👥 5</span>
                  <span>🧳 1</span>
                  <span>🚪 4</span>
                  <span>⚙️ A</span>
                  <span>❄️ A/C</span>
                </div>
                <div className={styles.location}>
                  📍 DXB: Dubai Intl
                  <br />
                  <span className={styles.pickupLink}>View alternative pick-up locations</span>
                </div>
                <ul className={styles.features}>
                  <li>✔ Free cancellation (48h)</li>
                  <li>✔ Fair fuel policy</li>
                  <li>✔ Unlimited kilometres</li>
                  <li>✔ Theft coverage</li>
                  <li>✔ Collision damage waiver</li>
                  <li>✔ Liability coverage</li>
                </ul>
                <div className={styles.providerRow}>
                  <div>
                    DiscoverCars.com
                    <br />
                    <strong>AED 1,649</strong>
                  </div>
                  <div>
                    DiscoverCars.com
                    <br />
                    <strong>AED 1,711</strong>
                  </div>
                  <div>
                    Argus Car Hire
                    <br />
                    <strong>AED 2,314</strong>
                  </div>
                  <div>
                    Holiday Autos
                    <br />
                    <strong>AED 2,303</strong>
                  </div>
                </div>
                
              </div>

              {/* Right section with pricing and button */}
              <div className={styles.right}>
                <div className={styles.provider} style={{ marginTop: '60px' }}>
                  EconomyBookings
                </div>
                <div className={styles.price}>AED 1,231</div>
                <div className={styles.note}>Total</div>
                <button className={styles.dealBtn}>View Deal</button>
              </div>
            </div>
      {/* Example Car Card */}
      <div className={styles.carCard} style={{marginTop:"50px"}}>
              {/* Left section with images */}
              <div className={styles.left}>
                <Image
                  src="/images/32_sedan_white.png"
                  alt="Car"
                  width={140}
                  height={100}
                  className={styles.image}
                />
                <div>
                  <Image
                    src="/images/company-logos/drive4less.jpg"
                    alt="Company"
                    width={140}
                    height={100}
                    className={styles.image1}
                  />
                </div>
              </div>

              {/* Middle section with details */}
              <div className={styles.middle}>
                <div className={styles.titleRow}>
                  <h3>Mitsubishi Mirage G4</h3>
                  <span className={styles.infoIcon}>ⓘ</span>
                </div>
                <p className={styles.subtext}>or similar Compact</p>
                <div className={styles.icons}>
                  <span>👥 5</span>
                  <span>🧳 1</span>
                  <span>🚪 4</span>
                  <span>⚙️ A</span>
                  <span>❄️ A/C</span>
                </div>
                <div className={styles.location}>
                  📍 DXB: Dubai Intl
                  <br />
                  <span className={styles.pickupLink}>View alternative pick-up locations</span>
                </div>
                <ul className={styles.features}>
                  <li>✔ Free cancellation (48h)</li>
                  <li>✔ Fair fuel policy</li>
                  <li>✔ Unlimited kilometres</li>
                  <li>✔ Theft coverage</li>
                  <li>✔ Collision damage waiver</li>
                  <li>✔ Liability coverage</li>
                </ul>
                <div className={styles.providerRow}>
                  <div>
                    DiscoverCars.com
                    <br />
                    <strong>AED 1,649</strong>
                  </div>
                  <div>
                    DiscoverCars.com
                    <br />
                    <strong>AED 1,711</strong>
                  </div>
                  <div>
                    Argus Car Hire
                    <br />
                    <strong>AED 2,314</strong>
                  </div>
                  <div>
                    Holiday Autos
                    <br />
                    <strong>AED 2,303</strong>
                  </div>
                </div>
                
              </div>

              {/* Right section with pricing and button */}
              <div className={styles.right}>
                <div className={styles.provider} style={{ marginTop: '60px' }}>
                  EconomyBookings
                </div>
                <div className={styles.price}>AED 1,231</div>
                <div className={styles.note}>Total</div>
                <button className={styles.dealBtn}>View Deal</button>
              </div>
            </div>
           
          </div>
        </div>
      </div>

      {/* Fixed Map */}
      <div className={styles.mapWrapper}>
        <iframe
          className={styles.map}
          title="Rental Location Map"
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3609.1695071737676!2d55.36443667534433!3d25.253174827315214!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e5f43474bb87a6f%3A0x44d6df1b20a0ac32!2sDubai%20International%20Airport!5e0!3m2!1sen!2sae!4v1648378305617!5m2!1sen!2sae"
          allowFullScreen
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
        ></iframe>
      </div>

    </>
  );
}
