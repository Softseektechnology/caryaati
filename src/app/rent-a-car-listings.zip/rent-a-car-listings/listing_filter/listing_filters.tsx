"use client";

import React, { useState, useEffect, useRef } from "react";
import { Form } from "react-bootstrap";
import { useRouter } from "next/navigation";
import { FaChevronLeft, FaChevronRight, FaStar } from "react-icons/fa";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import styles from "./list_filter.module.css";
import { ChevronDown, Star } from "react-bootstrap-icons";
import { SlidersHorizontal } from "lucide-react";
import ResultsSortBar from "../ResultsSortBar/ResultsSortBar";
import PriceAnalysisNotification from "../PriceAnalysisNotification/Price";
import Trackprice from "../PriceAnalysisNotification/Trackprices"

// Updated CustomCheckboxDropdown to support grouped options, footer buttons, Select All/Clear All, scrolling, and hover effects
const CustomCheckboxDropdown = ({
  options,
  selectedValues,
  onChange,
  leftIcon,
  dropdownLabel,
  dropdownLabel1,
  isTextInputMode = false,
  onTextSubmit,
  showLabelInTrigger = false,
  showFooter = false,
  onReset,
  resultCount = 0,
  showHeaderInsideDropdown = false,
  showSelectClearButtons = false,
}) => {
  const [showDropdown, setShowDropdown] = useState(false);
  const [textInput, setTextInput] = useState("");
  const dropdownRef = useRef<HTMLDivElement>(null);

  const handleToggleOption = (value: string) => {
    if (selectedValues.includes(value)) {
      onChange(selectedValues.filter((v) => v !== value));
    } else {
      onChange([...selectedValues, value]);
    }
  };

  // Handle "Select All" functionality
  const handleSelectAll = () => {
    const allValues = options.flatMap((group) =>
      (group.items || group).map((opt) => opt.value)
    );
    onChange(allValues);
  };

  // Handle "Clear All" functionality
  const handleClearAll = () => {
    onChange([]);
  };

  const handleTextSubmit = () => {
    if (textInput.trim() && onTextSubmit) {
      onTextSubmit(textInput);
      setTextInput("");
    }
  };

  const handleReset = () => {
    onChange([]); // Clear all selected values
    if (onReset) onReset();
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node)
      ) {
        setShowDropdown(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () =>
      document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div className={styles.filterItem} ref={dropdownRef}>
      <div
        className={styles.filterDropdown}
        onClick={() => setShowDropdown(!showDropdown)}
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          cursor: "pointer",
          fontWeight: "600",
          position: "relative",
          height: "40px",
          border: "1px solid #ddd",
          borderRadius: "12px",
          paddingLeft: leftIcon ? "34px" : "12px",
          paddingRight: "12px",
          background: "#fff",
          width: showLabelInTrigger ? "auto" : "45px",
          minWidth: showLabelInTrigger ? "120px" : "45px",
        }}
      >
        <div style={{ display: "flex", alignItems: "center" }}>
          {leftIcon && (
            <span
              style={{
                position: "absolute",
                left: "10px",
                display: "flex",
                alignItems: "center",
              }}
            >
              {leftIcon}
            </span>
          )}
          {showLabelInTrigger && (
            <span style={{ marginLeft: leftIcon ? "2px" : "0" }}>
              {dropdownLabel || dropdownLabel1}
            </span>
          )}
        </div>
        <ChevronDown size={14} />
      </div>
      {showDropdown && (
        <div
          className={styles.checkboxDropdown}
          style={{
            maxHeight: "300px", // Set a maximum height for the dropdown
            overflowY: "auto", // Enable vertical scrolling
            padding: "10px", // Add padding for better spacing
          }}
        >
          {/* Header with Dropdown Label */}
          {(showHeaderInsideDropdown || (isTextInputMode && dropdownLabel)) && (
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                paddingBottom: "10px",
                // borderBottom: "1px solid #ddd",
                // position: "sticky", // Make the header sticky at the top
                top: 0,
                background: "#fff", // Ensure the header has a background to avoid overlap
                zIndex: 1, // Ensure the header stays above the scrolling content
              }}
            >
              <h5 style={{ fontWeight: "700", marginBottom: "0" }}>
                {dropdownLabel || dropdownLabel1}
                {(dropdownLabel === "Smart Filters" || dropdownLabel1 === "Smart Filters") && (
                  <span
                    style={{ fontSize: "12px", color: "#666", marginLeft: "5px" }}
                  >
                    BETA • Powered by ChatGPT
                  </span>
                )}
              </h5>
              {/* Show Select All and Clear All buttons only if showSelectClearButtons is true */}
              {showSelectClearButtons && (
                <div style={{ display: "flex", alignItems: "center", gap: "5px" }}>
                  <button
                    onClick={handleSelectAll}
                    style={{
                      background: "none",
                      border: "none",
                      color: "#007bff",
                      cursor: "pointer",
                      fontWeight: "500",
                      fontSize: "14px",
                      transition: "color 0.2s ease", // Smooth transition for hover effect
                    }}
                    onMouseEnter={(e) => (e.currentTarget.style.color = "#0056b3")} // Darker blue on hover
                    onMouseLeave={(e) => (e.currentTarget.style.color = "#007bff")} // Original blue on leave
                  >
                    Select ALL
                  </button>
                  <span style={{ color: "black" }}>|</span>
                  <button
                    onClick={handleClearAll}
                    style={{
                      background: "none",
                      border: "none",
                      color: "#007bff",
                      cursor: "pointer",
                      fontWeight: "500",
                      fontSize: "14px",
                      transition: "color 0.2s ease", // Smooth transition for hover effect
                    }}
                    onMouseEnter={(e) => (e.currentTarget.style.color = "#0056b3")} // Darker blue on hover
                    onMouseLeave={(e) => (e.currentTarget.style.color = "#007bff")} // Original blue on leave
                  >
                    Clear all
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Dropdown Content */}
          {isTextInputMode ? (
            <div>
              <textarea
                placeholder="What are you looking for? Try something like: I want to see small cars less than £150."
                value={textInput}
                onChange={(e) => setTextInput(e.target.value)}
                style={{
                  width: "100%",
                  height: "80px",
                  padding: "8px",
                  border: "1px solid #ddd",
                  borderRadius: "4px",
                  marginBottom: "10px",
                  resize: "none",
                }}
              />
              <button
                onClick={handleTextSubmit}
                style={{
                  width: "100%",
                  padding: "8px",
                  backgroundColor: "#f5f5f5",
                  border: "1px solid #ddd",
                  borderRadius: "4px",
                  cursor: "pointer",
                  fontWeight: "500",
                }}
              >
                Filter cars
              </button>
            </div>
          ) : (
            <div>
              {options.map((group, groupIndex) => (
                <div key={groupIndex} style={{ marginBottom: "20px" }}>
                  {group.group && (
                    <h6 style={{ fontWeight: "700", marginBottom: "10px" }}>
                      {group.group}
                    </h6>
                  )}
                  {(group.items || group).map((opt) => (
                    <div
                      key={opt.value}
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        marginBottom: "10px",
                        padding: "5px 8px", // Add padding for better hover area
                        borderRadius: "4px", // Rounded corners for hover effect
                        transition: "background-color 0.2s ease", // Smooth transition for hover effect
                        cursor: "pointer", // Indicate the item is clickable
                      }}
                      onMouseEnter={(e) =>
                        (e.currentTarget.style.backgroundColor = "#f5f5f5")
                      } // Light gray background on hover
                      onMouseLeave={(e) =>
                        (e.currentTarget.style.backgroundColor = "transparent")
                      } // Reset background on leave
                    >
                      <label
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: "8px",
                          cursor: "pointer",
                          width: "50%", // Ensure the label takes full width for hover effect
                        }}
                      >
                        <input
                          type="checkbox"
                          checked={selectedValues.includes(opt.value)}
                          onChange={() => handleToggleOption(opt.value)}
                        />
                        {opt.label}
                      </label>
                      {opt.price && (
                        <span style={{ color: "#555", fontWeight: "500" }}>
                          {opt.price}
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              ))}
              {showFooter && (
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    marginTop: "20px",
                    borderTop: "1px solid #ddd",
                    paddingTop: "10px",
                    position: "sticky", // Make the footer sticky at the bottom
                    bottom: 0,
                    background: "#fff", // Ensure the footer has a background to avoid overlap
                    zIndex: 1, // Ensure the footer stays above the scrolling content
                  }}
                >
                  <button
                    onClick={handleReset}
                    style={{
                      padding: "8px 16px",
                      background: "none",
                      border: "1px solid #ddd",
                      borderRadius: "4px",
                      cursor: "pointer",
                      fontWeight: "500",
                      width: "30%",
                    }}
                  >
                    Reset
                  </button>
                  <button
                    onClick={() => setShowDropdown(false)}
                    style={{
                      padding: "8px 16px",
                      background: "#333",
                      color: "#fff",
                      border: "none",
                      borderRadius: "4px",
                      cursor: "pointer",
                      fontWeight: "500",
                      width: "67%",
                    }}
                  >
                    Show {resultCount} results
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

// New PriceRangeDropdown component for price range selection with histogram
const PriceRangeDropdown = ({
  dropdownLabel,
  showLabelInTrigger = false,
  showFooter = false,
  onReset,
  resultCount = 0,
  showHeaderInsideDropdown = false,
  onPriceChange,
}) => {
  const [showDropdown, setShowDropdown] = useState(false);
  const [priceRange, setPriceRange] = useState([47, 5885]); // Default range from AED 47 to AED 5,885
  const [priceType, setPriceType] = useState("Daily"); // Toggle between "Daily price" and "Total price"
  const dropdownRef = useRef<HTMLDivElement>(null);

  const minPrice = 47;
  const maxPrice = 5885;

  const handlePriceChange = (e) => {
    const newRange = [parseInt(e.target.value[0]), parseInt(e.target.value[1])];
    setPriceRange(newRange);
    if (onPriceChange) {
      onPriceChange(newRange);
    }
  };

  const handleReset = () => {
    setPriceRange([minPrice, maxPrice]);
    if (onReset) onReset();
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node)
      ) {
        setShowDropdown(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () =>
      document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Simulate a histogram with bars (for visual representation)
  const histogramBars = Array(20).fill(0).map((_, i) => {
    const height = Math.random() * 50 + 10; // Random height for demo purposes
    return (
      <div
        key={i}
        style={{
          height: `${height}px`,
          width: "5px",
          backgroundColor: "#333",
          marginRight: "2px",
        }}
      />
    );
  });

  return (
    <div className={styles.filterItem} ref={dropdownRef}>
      <div
        className={styles.filterDropdown}
        onClick={() => setShowDropdown(!showDropdown)}
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          cursor: "pointer",
          fontWeight: "600",
          position: "relative",
          height: "40px",
          border: "1px solid #ddd",
          borderRadius: "12px",
          paddingLeft: "12px",
          paddingRight: "12px",
          background: "#fff",
          width: showLabelInTrigger ? "auto" : "45px",
          minWidth: showLabelInTrigger ? "120px" : "45px",
        }}
      >
        <div style={{ display: "flex", alignItems: "center" }}>
          {showLabelInTrigger && <span>{dropdownLabel}</span>}
        </div>
        <ChevronDown size={14} />
      </div>
      {showDropdown && (
        <div
          className={styles.checkboxDropdown}
          style={{
            maxHeight: "300px",
            overflowY: "auto",
            padding: "10px",
          }}
        >
          {/* Header */}
          {showHeaderInsideDropdown && (
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                paddingBottom: "10px",
                borderBottom: "1px solid #ddd",
                position: "sticky",
                top: 0,
                background: "#fff",
                zIndex: 1,
              }}
            >
              <h5 style={{ fontWeight: "700", marginBottom: "0" }}>
                {dropdownLabel}
              </h5>
            </div>
          )}

          {/* Price Type Toggle */}
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              marginBottom: "10px",
            }}
          >
            <button
              onClick={() => setPriceType("Daily")}
              style={{
                padding: "5px 10px",
                backgroundColor: priceType === "Daily" ? "#f5f5f5" : "transparent",
                border: "1px solid #ddd",
                borderRadius: "4px",
                cursor: "pointer",
                fontWeight: "500",
              }}
            >
              Daily price
            </button>
            <button
              onClick={() => setPriceType("Total")}
              style={{
                padding: "5px 10px",
                backgroundColor: priceType === "Total" ? "#f5f5f5" : "transparent",
                border: "1px solid #ddd",
                borderRadius: "4px",
                cursor: "pointer",
                fontWeight: "500",
              }}
            >
              Total price
            </button>
          </div>

          {/* Histogram and Range Slider */}
          <div style={{ marginBottom: "20px" }}>
            {/* Histogram */}
            <div
              style={{
                display: "flex",
                alignItems: "flex-end",
                height: "60px",
                marginBottom: "10px",
              }}
            >
              {histogramBars}
            </div>

            {/* Range Slider */}
            <div style={{ position: "relative" }}>
              <input
                type="range"
                min={minPrice}
                max={maxPrice}
                value={priceRange[0]}
                onChange={(e) =>
                  handlePriceChange({
                    target: { value: [e.target.value, priceRange[1]] },
                  })
                }
                style={{
                  position: "absolute",
                  width: "100%",
                  zIndex: 2,
                  background: "transparent",
                  pointerEvents: "none",
                }}
              />
              <input
                type="range"
                min={minPrice}
                max={maxPrice}
                value={priceRange[1]}
                onChange={(e) =>
                  handlePriceChange({
                    target: { value: [priceRange[0], e.target.value] },
                  })
                }
                style={{
                  position: "absolute",
                  width: "100%",
                  zIndex: 2,
                  background: "transparent",
                  pointerEvents: "none",
                }}
              />
              <div
                style={{
                  position: "relative",
                  height: "5px",
                  background: "#ddd",
                  borderRadius: "5px",
                }}
              >
                <div
                  style={{
                    position: "absolute",
                    height: "5px",
                    background: "#333",
                    borderRadius: "5px",
                    left: `${((priceRange[0] - minPrice) / (maxPrice - minPrice)) * 100}%`,
                    right: `${100 - ((priceRange[1] - minPrice) / (maxPrice - minPrice)) * 100}%`,
                  }}
                />
              </div>
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  marginTop: "10px",
                }}
              >
                <span style={{ fontWeight: "500" }}>AED {priceRange[0]}</span>
                <span style={{ fontWeight: "500" }}>AED {priceRange[1]}</span>
              </div>
            </div>
          </div>

          {/* Footer */}
          {showFooter && (
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                marginTop: "20px",
                borderTop: "1px solid #ddd",
                paddingTop: "10px",
                position: "sticky",
                bottom: 0,
                background: "#fff",
                zIndex: 1,
              }}
            >
              <button
                onClick={handleReset}
                style={{
                  padding: "8px 16px",
                  background: "none",
                  border: "1px solid #ddd",
                  borderRadius: "4px",
                  cursor: "pointer",
                  fontWeight: "500",
                  width: "30%",
                }}
              >
                Reset
              </button>
              <button
                onClick={() => setShowDropdown(false)}
                style={{
                  padding: "8px 16px",
                  background: "#333",
                  color: "#fff",
                  border: "none",
                  borderRadius: "4px",
                  cursor: "pointer",
                  fontWeight: "500",
                  width: "67%",
                }}
              >
                Show {resultCount} results
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default function SearchForm() {
  const router = useRouter();
  const [formData, setFormData] = useState({
    carType: "",
    capacity: "",
    transmission: "",
    carFeatures: "",
    smartFilter: "",
    priceRange: [47, 5885], // Add price range to formData
  });
  const [isMounted, setIsMounted] = useState(false);
  const filterContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setIsMounted(true);
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSmartFilterSubmit = (text: string) => {
    setFormData({ ...formData, smartFilter: text });
    console.log("Smart Filter applied:", text);
  };

  const handleCarFeaturesChange = (values) => {
    setFormData({ ...formData, carFeatures: values.join(",") });
  };

  const handlePriceChange = (newRange) => {
    setFormData({ ...formData, priceRange: newRange });
    console.log("Price range applied:", newRange);
  };

  const handleResetCarFeatures = () => {
    setFormData({ ...formData, carFeatures: "" });
  };

  const handleResetPrice = () => {
    setFormData({ ...formData, priceRange: [47, 5885] });
  };

  const scrollLeft = () => {
    if (filterContainerRef.current) {
      filterContainerRef.current.scrollBy({ left: -150, behavior: "smooth" });
    }
  };

  const scrollRight = () => {
    if (filterContainerRef.current) {
      filterContainerRef.current.scrollBy({ left: 150, behavior: "smooth" });
    }
  };

  if (!isMounted) return null;

  return (
    <div className={styles.searchSection}>
      <div className={styles.filterBar}>
        <div className={styles.filterContainer} ref={filterContainerRef}>
          {/* Car Features Dropdown (with Transmission and Car features) */}
          <CustomCheckboxDropdown
            leftIcon={<SlidersHorizontal size={16} color="#333" />}
            dropdownLabel="Car features"
            options={[
              {
                group: "Transmission",
                items: [
                  { value: "automatic2", label: "Automatic", price: "AED 1,268" },
                  { value: "manual2", label: "Manual", price: "AED 2,552" },
                ],
              },
              {
                group: "Car features",
                items: [
                  { value: "4doors", label: "4+ doors", price: "AED 1,268" },
                  { value: "4wd", label: "4WD", price: "AED 2,583" },
                  { value: "aircon", label: "Aircon", price: "AED 1,268" },
                  { value: "awd", label: "AWD", price: "AED 4,481" },
                  { value: "coupe", label: "Coupe", price: "AED 7,295" },
                ],
              },
            ]}
            selectedValues={formData.carFeatures ? formData.carFeatures.split(",") : []}
            onChange={handleCarFeaturesChange}
            showLabelInTrigger={false}
            showFooter={true}
            onReset={handleResetCarFeatures}
            resultCount={449}
          />

          {/* Smart Filters Dropdown */}
          <CustomCheckboxDropdown
            leftIcon={<FaStar size={16} color="#333" />}
            dropdownLabel="Smart Filters"
            isTextInputMode={true}
            onTextSubmit={handleSmartFilterSubmit}
            options={[]}
            selectedValues={[]}
            onChange={() => {}}
            showLabelInTrigger={true}
          />

          {/* Car Type */}
          <CustomCheckboxDropdown
            dropdownLabel1="Car Type"
            options={[
              {
                group: "",
                items: [
                  { value: "small", label: "Small", price: "AED 1,200" },
                  { value: "medium", label: "Medium", price: "AED 1,450" },
                  { value: "large", label: "Large", price: "AED 1,600" },
                  { value: "suv", label: "SUV", price: "AED 1,950" },
                ],
              },
            ]}
            selectedValues={formData.capacity ? formData.capacity.split(",") : []}
            onChange={(values) =>
              setFormData({ ...formData, capacity: values.join(",") })
            }
            showLabelInTrigger={true}
            showFooter={true}
            onReset={() => setFormData({ ...formData, capacity: "" })}
            resultCount={449}
            showHeaderInsideDropdown={true}
          />

          {/* Capacity Dropdown */}
          <CustomCheckboxDropdown
            dropdownLabel1="Capacity"
            options={[
              {
                group: "Passengers",
                items: [
                  { value: "1to2", label: "1 to 2 passengers", price: "AED 1,200" },
                  { value: "3to5", label: "3 to 5 passengers", price: "AED 1,450" },
                  { value: "6", label: "6 or more", price: "AED 1,600" },
                ],
              },
              {
                group: "Bags",
                items: [
                  { value: "1bag", label: "1 to 2 bags", price: "AED 1,268" },
                  { value: "2bag", label: "3 to 4 bags", price: "AED 7,295" },
                ],
              },
            ]}
            selectedValues={formData.capacity ? formData.capacity.split(",") : []}
            onChange={(values) =>
              setFormData({ ...formData, capacity: values.join(",") })
            }
            showLabelInTrigger={true}
            showFooter={true}
            onReset={() => setFormData({ ...formData, capacity: "" })}
            resultCount={449}
            showHeaderInsideDropdown={true}
          />

          {/* Transmission Dropdown */}
          <CustomCheckboxDropdown
            dropdownLabel1="Transmission"
            options={[
              {
                group: "",
                items: [
                  { value: "automatic2", label: "Automatic", price: "AED 1,268" },
                  { value: "manual2", label: "Manual", price: "AED 2,552" },
                ],
              },
            ]}
            selectedValues={formData.capacity ? formData.capacity.split(",") : []}
            onChange={(values) =>
              setFormData({ ...formData, capacity: values.join(",") })
            }
            showLabelInTrigger={true}
            showFooter={true}
            onReset={() => setFormData({ ...formData, capacity: "" })}
            resultCount={449}
            showHeaderInsideDropdown={true}
          />

          {/* Car Features Dropdown */}
          <CustomCheckboxDropdown
            dropdownLabel1="Car Features"
            options={[
              {
                items: [
                  { value: "4+door", label: "4 + Door", price: "AED 1,268" },
                  { value: "4wd", label: "4WD", price: "AED 2,552" },
                  { value: "aircon", label: "Aircon", price: "AED 2,552" },
                  { value: "awd", label: "AWD", price: "AED 2,552" },
                  { value: "coupe", label: "coupe", price: "AED 2,552" },
                  { value: "estatecar", label: "Estate Car", price: "AED 2,552" },
                  { value: "open-air", label: "open-air-all-terrain", price: "AED 2,552" },
                ],
              },
            ]}
            selectedValues={formData.capacity ? formData.capacity.split(",") : []}
            onChange={(values) =>
              setFormData({ ...formData, capacity: values.join(",") })
            }
            showLabelInTrigger={true}
            showFooter={true}
            onReset={() => setFormData({ ...formData, capacity: "" })}
            resultCount={449}
            showHeaderInsideDropdown={true}
          />

          {/* Policies Dropdown */}
          <CustomCheckboxDropdown
            dropdownLabel1="Policies"
            options={[
              {
                items: [
                  { value: "free", label: "Free cancellation", price: "AED 1,268" },
                  { value: "fair", label: "Fair Fuel Policy", price: "AED 2,552" },
                  { value: "unlimited", label: "Unlimited mileage", price: "AED 2,552" },
                ],
              },
            ]}
            selectedValues={formData.capacity ? formData.capacity.split(",") : []}
            onChange={(values) =>
              setFormData({ ...formData, capacity: values.join(",") })
            }
            showLabelInTrigger={true}
            showFooter={true}
            onReset={() => setFormData({ ...formData, capacity: "" })}
            resultCount={449}
            showHeaderInsideDropdown={true}
          />

          {/* Supplier Dropdown with Select All and Clear All buttons */}
          <CustomCheckboxDropdown
            dropdownLabel1="Supplier"
            options={[
              {
                items: [
                  { value: "Free-cancellation", label: "Free Cancellation", price: "AED 1,268" },
                  { value: "fair", label: "Fair Fuel Policy", price: "AED 2,552" },
                  { value: "ulimited", label: "Unlimited mileage", price: "AED 2,552" },
                  { value: "Free-cancellation", label: "Free Cancellation", price: "AED 1,268" },
                  { value: "fair", label: "Fair Fuel Policy", price: "AED 2,552" },
                  { value: "ulimited", label: "Unlimited mileage", price: "AED 2,552" },
                ],
              },
            ]}
            selectedValues={formData.capacity ? formData.capacity.split(",") : []}
            onChange={(values) =>
              setFormData({ ...formData, capacity: values.join(",") })
            }
            showLabelInTrigger={true}
            showFooter={true}
            onReset={() => setFormData({ ...formData, capacity: "" })}
            resultCount={449}
            showHeaderInsideDropdown={true}
            showSelectClearButtons={true}
          />

          {/* Location */}
          <CustomCheckboxDropdown
            dropdownLabel1="Location"
            options={[
              {
                group: "DXB: Dubai Intl",
                items: [
                  { value: "at", label: "At Terminal", price: "AED 1,450" },
                  { value: "shu", label: "Shuttle", price: "AED 1,600" },
                  { value: "call", label: "Call for pick-up", price: "AED 1,950" },
                ],
              },
            ]}
            selectedValues={formData.capacity ? formData.capacity.split(",") : []}
            onChange={(values) =>
              setFormData({ ...formData, capacity: values.join(",") })
            }
            showLabelInTrigger={true}
            showFooter={true}
            onReset={() => setFormData({ ...formData, capacity: "" })}
            resultCount={449}
            showHeaderInsideDropdown={true}
          />

          {/* Payment Type */}
          <CustomCheckboxDropdown
            dropdownLabel1="Payment Type"
            options={[
              {
                group: "",
                items: [
                  { value: "now", label: "Pay now", price: "AED 1,450" },
                  { value: "par", label: "Partial Perpayment", price: "AED 1,600" },
                  { value: "pay", label: "Pay at counter", price: "AED 1,950" },
                ],
              },
            ]}
            selectedValues={formData.capacity ? formData.capacity.split(",") : []}
            onChange={(values) =>
              setFormData({ ...formData, capacity: values.join(",") })
            }
            showLabelInTrigger={true}
            showFooter={true}
            onReset={() => setFormData({ ...formData, capacity: "" })}
            resultCount={449}
            showHeaderInsideDropdown={true}
          />

          {/* Payment Type (Duplicate) */}
          <CustomCheckboxDropdown
            dropdownLabel1="Payment Type"
            options={[
              {
                group: "",
                items: [
                  { value: "now", label: "Pay now", price: "AED 1,450" },
                  { value: "par", label: "Partial Perpayment", price: "AED 1,600" },
                  { value: "pay", label: "Pay at counter", price: "AED 1,950" },
                ],
              },
            ]}
            selectedValues={formData.capacity ? formData.capacity.split(",") : []}
            onChange={(values) =>
              setFormData({ ...formData, capacity: values.join(",") })
            }
            showLabelInTrigger={true}
            showFooter={true}
            onReset={() => setFormData({ ...formData, capacity: "" })}
            resultCount={449}
            showHeaderInsideDropdown={true}
          />

          {/* Price Range Dropdown */}
          <PriceRangeDropdown
            dropdownLabel="Price with taxes and fees"
            showLabelInTrigger={true}
            showFooter={true}
            onReset={handleResetPrice}
            resultCount={453} // Match the image
            showHeaderInsideDropdown={true}
            onPriceChange={handlePriceChange}
          />
        </div>

        <button className={styles.scrollButtonLeft} onClick={scrollLeft}>
          <FaChevronLeft />
        </button>
        <button className={styles.scrollButtonRight} onClick={scrollRight}>
          <FaChevronRight />
        </button>
      </div>
        {/* Add the ResultsSortBar component below the filter bar */}
            <ResultsSortBar resultCount={375} defaultSort="Our recommendation" />
       {/* Add the PriceAnalysisNotification component below the ResultsSortBar */}
<PriceAnalysisNotification />
 {/* Add the trackprice component below the ResultsSortBar */}
 <Trackprice />


    </div>
  );
}