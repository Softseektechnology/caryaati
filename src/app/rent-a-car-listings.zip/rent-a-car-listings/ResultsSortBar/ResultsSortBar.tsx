// components/ResultsSortBar.jsx
import React, { useState } from "react";
import { ChevronDown } from "react-bootstrap-icons";
import styles from "./resultsSortBar.module.css"; // We'll create this CSS module for styling

const ResultsSortBar = ({ resultCount = 375, defaultSort = "Our recommendation" }) => {
  const [showSortDropdown, setShowSortDropdown] = useState(false);
  const [selectedSort, setSelectedSort] = useState(defaultSort);

  const sortOptions = [
    { value: "our_recommendation", label: "Our recommendation" },
    { value: "price_low_to_high", label: "Price: Low to High" },
    { value: "price_high_to_low", label: "Price: High to Low" },
    { value: "rating", label: "Rating" },
  ];

  const handleSortChange = (option) => {
    setSelectedSort(option.label);
    setShowSortDropdown(false);
    // Add logic here to handle sorting if needed (e.g., update parent state or fetch new data)
    console.log("Sort by:", option.value);
  };

  return (
    <div className={styles.resultsSortBar} style={{width:"60%",marginLeft:"50px"}}>
      <div className={styles.resultsCount}  >{resultCount} results</div>
      <div className={styles.sortContainer}>
      <span style={{ marginLeft: "50px" }}>Sort by:</span>
       <div
          className={styles.sortDropdown} 
          onClick={() => setShowSortDropdown(!showSortDropdown)}
        >
          <span>{selectedSort}</span>
          <ChevronDown size={14} style={{ marginLeft: "5px" }} />
        </div>
        {showSortDropdown && (
          <div className={styles.sortDropdownMenu}>
            {sortOptions.map((option) => (
              <div
                key={option.value}
                className={styles.sortOption}
                onClick={() => handleSortChange(option)}
              >
                {option.label}
              </div>
            ))}
          </div>
        )}
        <span className={styles.infoIcon}>ⓘ</span>
      </div>
    </div>
  );
};

export default ResultsSortBar;