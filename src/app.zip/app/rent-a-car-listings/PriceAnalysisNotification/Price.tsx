// components/PriceAnalysisNotification.jsx
import React, { useState } from "react";
import styles from "./Price.module.css";
import { X } from "react-bootstrap-icons";

const PriceAnalysisNotification = () => {
  const [isVisible, setIsVisible] = useState(true);
  const [trackPrices, setTrackPrices] = useState(false);

  const handleClose = () => {
    setIsVisible(false);
  };

  const handleToggleTrackPrices = () => {
    setTrackPrices(!trackPrices);
    // Add logic here to handle tracking prices if needed
    console.log("Track prices:", !trackPrices);
  };

  if (!isVisible) return null;

  return (
    <div className={styles.notificationBar} style={{width:"60%",marginLeft:"50px"}}>
      <div className={styles.content}>
        <div className={styles.icon} style={{marginTop:"-04px"}}>C</div>
        <div className={styles.textContent}>
          <div className={styles.link} style={{marginLeft:"px"}}>
            How payments to us affect ranking{" "}
            <span className={styles.moreInfo} style={{marginLeft:"10px"}}>MORE INFO</span>
            <button className={styles.closeButton} onClick={handleClose}>
          <X size={22} />
        </button>
          </div>
          
        </div></div>
    </div>
    
  );
};

export default PriceAnalysisNotification;