// components/PriceAnalysisNotification.jsx
import React, { useState } from "react";
import styles from "./Price.module.css";
import { X } from "react-bootstrap-icons";

const Trackprice = () => {
  const [isVisible, setIsVisible] = useState(true);
  const [trackPrices, setTrackPrices] = useState(false);

  const handleClose = () => {
    setIsVisible(false);
  };

  const handleToggleTrackPrices = () => {
    setTrackPrices(!trackPrices);
    // Add logic here to handle tracking prices if needed
    console.log("Track prices:", !trackPrices);
  };

  if (!isVisible) return null;

  return (
    <div className={styles.notificationBar} style={{width:"60%",marginLeft:"50px"}}>
      <div className={styles.content}>
      
          <div className={styles.analyzing}>
            <span className={styles.spinner}>⏳</span> Analysing price trends...
       
      <div className={styles.actions}>
        <div className={styles.trackPrices}>
          <span>Track prices:</span>
          <label className={styles.switch}>
            <input
              type="checkbox"
              checked={trackPrices}
              onChange={handleToggleTrackPrices}
            />
            <span className={styles.slider}></span>
          </label>
        </div>
       </div></div>
      </div>
        </div>
    
  );
};

export default Trackprice;