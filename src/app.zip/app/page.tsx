'use client';

import { useState } from 'react';
import Image from 'next/image';
import Navbar from '../components/nevegation-header/Navbar';
import Sidebar from '../components/multiplepages/Sidebar-multiplelinks';
import UserDropdown from '../components/customer-dashboard/user-dashboard';
import Subcategory from '../components/homepage-subcategory/allCarscategory';
import Footer from '../components/foorter/Footer';
import Carcategory from '../components/car-categories/index-car-categories';
import FAQPage from '../components/faq/faq';
import styles from '../../public/styles/Home.module.css';
import SearchEngine from '../components/search-engine/search-console';

export default function Home() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [imageFailed, setImageFailed] = useState(false);

  const handleSidebarClose = () => {
    setIsSidebarOpen(false);
  };

  return (
    <div className={styles.container}>
      <Navbar
        onMenuToggle={() => {
          setIsSidebarOpen(!isSidebarOpen);
          setIsDropdownOpen(false);
        }}
        onUserToggle={() => {
          setIsDropdownOpen(!isDropdownOpen);
          setIsSidebarOpen(false);
        }}
      />
      <Sidebar isOpen={isSidebarOpen} onClose={handleSidebarClose} />
      <UserDropdown isOpen={isDropdownOpen} />
      <main className={styles.mainContent}>
        <div className="container text-center">
          <h1 className={styles.mainHeading}>Caryaati - Seamless Car Rental Solutions</h1>
          <Carcategory />
          <SearchEngine />
          <div style={{ marginTop: '50px' }}>
            <Subcategory /> {/* Updated to use allCarscategory.tsx */}
          </div>
        </div>
      </main>
      <FAQPage />
      <Footer />
    </div>
  );
}